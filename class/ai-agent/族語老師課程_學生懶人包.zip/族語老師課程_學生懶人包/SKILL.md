---
name: language-teacher-course-pack
description: 為族語教師課程選用本機教材製作技能；當學員要求安裝或選擇本懶人包時使用。
---

# 學生懶人包安裝入口

先讀同層 `README.md`，向學員說明四項可選技能：`lesson-plan`、`storybook`、`interactive-practice`、`material-check`。詢問要選哪項；如果學員已指定，就直接處理指定項目。

安裝前確認目前開啟的是學員自己的練習專案，以及懶人包的本機路徑。只複製所選的完整資料夾到該專案 `.agents/skills/`。同名技能存在時先比較，沒有學員明確選擇就不要覆蓋。不要更動全域設定、安裝第三方程式、連接雲端帳號或發布作品。

完成後逐項回報目的地、是否可讀取 `SKILL.md`，以及一個用示範素材試跑的步驟。學員使用的 AI 助理若不支援專案技能，提供直接閱讀或貼上選定 `SKILL.md` 的做法。
