﻿第二課：免費 AI 助手 OpenCode：族語老師的四步驟（2026-11-03 製作）
範例內容請依教育部書寫系統與本族方言別校對

OpenCode族語老師四步驟_講義.docx / .pdf   學員講義（18 頁，第 17–18 頁為提示詞小抄）
提示詞小抄_OpenCode.docx / .pdf           單頁提示詞小抄（A4 一頁）
族語單字卡講義.docx / .pdf                範例：秀姑巒阿美語單字卡（3 頁）
族語單字卡講義技能/SKILL.md               範例技能（懶人包 SKILL.md 格式，【】待填）
華語說明旁白.mp3 / _講稿.txt              範例：Edge TTS zh-TW-HsiaoChenNeural，約 28 秒，只有華語
參考資料/edge_tts_voices_20261103.txt     Edge TTS 聲音清單（322 個；無台灣原住民族語言）
images/  previews/                        圖片、預覽圖

來源：「OpenCode 從零開始」https://www.youtube.com/watch?v=hiHkWkvycwA
      「OpenCode 基本功 EP01」https://www.youtube.com/watch?v=lB7Pl8Dl_Rw
族語詞彙：秀姑巒阿美語 族語學習詞表（109 年 12 月版，原住民族委員會／原住民族語言研究發展基金會）
