# 來源與改編紀錄

## 上游

- 儲存庫：<https://github.com/mathruffian-dot/opencode-lazy-packs>
- 固定版本：[`bad3568bc3e898b01dee3d40f8a0ca447ef2b70c`](https://github.com/mathruffian-dot/opencode-lazy-packs/commit/bad3568bc3e898b01dee3d40f8a0ca447ef2b70c)
- 上游提交時間：2026-09-04 00:01:38 UTC；下載與整理日期：2026-11-03（台灣）。
- 授權：[上游 MIT LICENSE](https://github.com/mathruffian-dot/opencode-lazy-packs/blob/bad3568bc3e898b01dee3d40f8a0ca447ef2b70c/LICENSE)，本地 [LICENSE](LICENSE) 保留原始位元內容。
- 逐檔來源路徑、Git blob SHA、SHA-256 與本地對應路徑見 [maintenance/upstream.json](maintenance/upstream.json)。

## 本次實際改動

1. 保存全部 19 個來源檔案：11 份主教材、2 份補充教材、授權及 5 份根目錄參考文件。來源根目錄 README、AGENTS、CHANGELOG、SKILL 與 gitignore 改放 `references/upstream-*.txt`，避免把原始專案指令誤作本包入口。
2. 新增 Calumai 品牌入口、教材索引、使用規則與維護流程；移除參考導覽中的原作者姓名與頻道宣傳。LICENSE 因 MIT 條件保留原文；原始來源網址保留供查核。
3. 各教材加上 Calumai 標題與使用界線；保留 OpenCode 產品名稱、設定格式、技術識別字和來源連結，避免改壞指令。
4. 工作流程教材修訂 Git push、遠端 repo 建立與複製子技能的授權規則，不再把收工或初始化視為遠端操作的許可。
5. 新增只讀上游的 PowerShell 檢查工具，產生本地報告；維護時不直接覆蓋教材。

上游的版本歷程保存在 `references/upstream-CHANGELOG.txt`；Calumai 本次工作沿用專案的 `docs/WORKLOG.md`，不把上游歷程冒充本地實作。

## 尚未重新查證的部分

- 此次只整理檔案，未逐一安裝或連線 13 份教材的工具；模型、平台方案、額度、版本、套件 ID 與外部安裝腳本需使用前重查官方資料。
- `extras/` 是上游保留的較舊補充內容，不視為已驗證的推薦路線。
- `skills/02-file-toolkit/SKILL.md` 連結另一個 `mathruffian-dot/ai-agent-ep03` 儲存庫；本包未下載其程式，也未把它的授權視為已確認。
- 外部服務、軟體、影片與其他連結各有自己的授權及費用；MIT 授權僅及於本次來源涵蓋的內容。
- 新增內容由 Calumai 整理；上游改編部分沿用原始 MIT 授權條件，沒有宣稱 Calumai 是上游作者。
