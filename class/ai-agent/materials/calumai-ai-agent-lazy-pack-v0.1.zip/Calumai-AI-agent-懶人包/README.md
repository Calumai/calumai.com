# Calumai AI agent 懶人包

給老師與創作者的 AI Agent 教材集。保留可修改的 Markdown 原稿，從環境、檔案工具、知識整理，到網站資料與工作交接，按需要選用。

**版本：0.1.0｜整理日期：2026-11-03｜11 個主教材＋2 個補充技能。**

本版改編自 OpenCode 教材，操作指令與設定仍以 OpenCode 為主。Calumai 是這份教材的整理與維護品牌；不是另一套 AI 軟體，也不代表所有指令能直接用在 Codex、Claude Code 或其他 Agent。

## 第一次使用

1. 先看 [Calumai 使用規則](PACK-RULES.md)，確認你要「閱讀教材」或「實際操作」。下載不會安裝任何軟體。
2. 在下表點一份教材。用 VS Code、Obsidian 或文字編輯器開啟 `SKILL.md`，可以閱讀與修改。
3. 在目前的 AI 工具加入這個資料夾，或貼上教材內容與下列提示詞。已經有可用的 AI，就先使用既有工具，不必為了讀教材另開 API 帳號。
4. AI 先回報現況與要做的項目；依你已同意的範圍操作，完成後應看到版本號、測試輸出或實際檔案。只有檢查通過才能說完成。

可直接貼給 AI：

```text
我要使用「Calumai AI agent 懶人包」。
先讀 PACK-RULES.md，再讀 SKILL.md 與我指定的教材。
本次先處理【填入教材編號與目標】，檢查現有工具，保留可修改的源稿。
優先使用目前的 AI Session 與專案既有工具。
外部 AI API、API Key、付費服務、Git 推送、建立遠端儲存庫、部署與發送訊息，未經我明確同意不要執行。
請用台灣繁體中文說明在哪裡點、輸入什麼，以及成功後會看到什麼。
```

## 教材索引

| 編號 | 教材 | 用途與注意事項 |
| --- | --- | --- |
| 00 | [環境建置](skills/00-env-setup/SKILL.md) | OpenCode、Git、GitHub CLI、Node.js、uv；先查現況，缺少才安裝。 |
| 01 | [連接模型](skills/01-connect-model/SKILL.md) | 介紹 OpenCode 的模型連線方式；帳號、免費額度與費用需當次確認。 |
| 02 | [檔案工具包](skills/02-file-toolkit/SKILL.md) | 文件、影音、語音工具；另依賴外部工具庫，本包未附那些程式。 |
| 03 | [NotebookLM](skills/03-notebooklm/SKILL.md) | 連接知識整理工具；先確認帳號與資料可否上傳。 |
| 04 | [Obsidian](skills/04-obsidian/SKILL.md) | 整理本機筆記與專案知識。 |
| 05 | [Google Sheets 與 Apps Script](skills/05-sheets-gas/SKILL.md) | 試算表資料與網站後端；發布與權限另行確認。 |
| 06 | [Supabase](skills/06-supabase/SKILL.md) | 即時資料庫；不可直接對正式資料執行範例。 |
| 07 | [GitHub](skills/07-github/SKILL.md) | 版本紀錄與跨電腦協作；推送與建立遠端儲存庫需明確授權。 |
| 08 | [開工、收工與初始化](skills/08-workflow-skills/SKILL.md) | 保存交接資訊；Calumai 版已補上遠端操作授權界線。 |
| 09 | [Groq API](skills/09-groq-api/SKILL.md) | 語音辨識與文字處理的選讀教材；不是預設必做項目。 |
| 10 | [Netlify](skills/10-netlify/SKILL.md) | 部署與後端的選讀教材；不會因下載本包而自動部署。 |
| 補充 | [Firebase](extras/firebase/SKILL.md) | 另一種資料庫與網站服務；上游列為較舊補充教材。 |
| 補充 | [瀏覽器控制](extras/browser/SKILL.md) | 瀏覽器操作工具；優先使用目前 Session 已有能力。 |

初次設定 OpenCode，可按 00 → 01 閱讀；已有可用 AI 環境者，依目標選讀，不必全套安裝。涉及 API 或部署的 09、10 為選讀。

## 後續怎麼維護

- 教材原稿：直接編輯 `skills/`、`extras/` 與本文件，這裡就是 Calumai 維護版。
- [維護操作](maintenance/README.md)：每週檢查上游變更，先產生差異清單，確認後才合併。
- [來源與改編紀錄](SOURCES.md)：來源版本、實際修改及尚未查證的內容。
- [驗收紀錄](VALIDATION.md)：本次檢查結果與未測項目。
- [AI 使用入口](SKILL.md)：讓 Agent 依需求選教材。

本包保留上游 MIT 授權。[LICENSE](LICENSE) 的原始著作權聲明依法須保留；教材正文與導覽已移除原作者姓名與頻道宣傳。Calumai 不宣稱上游內容為自己原創。下載包保留的是來源文件，不包含來源另行連結的軟體、影片或其他儲存庫。
