# 定期維護

在懶人包資料夾內，於 PowerShell 執行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\maintenance\Check-Upstream.ps1
```

完成後開啟 [檢查報告](reports/latest.md)。報告分開列出教材、其他上游檔案，以及本地編修／缺檔；`latest.json` 提供相同的結構化結果。上游沒有新版本時，也會核對 `upstream.json` 中記錄的本地 SHA256。本地編修是資訊紀錄，不代表錯誤。

本地檢查範圍限於 `local_files` 已登記的檔案；新建但尚未登記的檔案不會列入數量。維護合併前仍需查看資料夾，避免遺漏新增教材；`local_changes=0` 只表示已登記檔案符合最近驗收基準。

這個腳本只讀公開 GitHub API，並寫入本機兩份報告；不安裝工具、不執行來源程式、不使用外部 AI、不覆蓋教材。網路或資料格式錯誤會顯示原因並回傳非零狀態。

## 有更新時

1. 依報告列出的固定 commit，到上游查看新增、修改、刪除的檔案。
2. 核對官方文件、授權與實際工具畫面；保留 Calumai 的在地編修與操作授權邊界，不整包覆蓋。
3. 人工合併後完成驗收、更新版本紀錄，再更新 `upstream.json` 的來源版本與檔案雜湊。本地雜湊代表最近一次人工確認的基準，不能只為消除提示而重算。

如果只接受部分上游變更，保留尚未合併項目的舊 blob SHA，並註明跳過原因；不可把整個新版本當成已全部接受。`local_files` 不記錄 manifest 自己或 `maintenance/reports/`，避免檢查報告每次更新都被當成教材編修。

第三方授權聲明仍須保留；教材去除推廣姓名，不代表可刪除原作者著作權聲明。下載教材也不代表已獲准安裝軟體、建立 API Key、推送 Git 或發布網站。

## 本機定期維護

已在 Codex 本次對話建立「維護 Calumai AI agent 懶人包」排程，預設每週一上午 9:00（Asia/Taipei）。這是本機維護，需 Codex 所需的執行環境可用；複製或解壓縮這份教材不會自動建立排程。

排程先檢查來源，再審閱實際差異；可核實、可逆的教材修正才合併本地版本。授權變更、重大改版或不明指令會留下待決事項。沒有新的實質變更就靜默完成；有教材更新、新失敗或需要判斷時才回報。它不安裝教材工具、不推送或部署。

要調整時間，可直接在原對話說「把 Calumai 懶人包維護改成……」，或到 Codex 的自動化項目編輯。排程識別碼：`calumai-ai-agent`。

## 離線驗證

可用 GitHub tree 格式的 JSON 測試，不連網：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\maintenance\Check-Upstream.ps1 -PackRoot C:\測試資料夾 -OfflineTreeFile C:\測試資料夾\tree.json -OfflineCommit 完整40碼commit
```

兩個離線參數須一起提供；`-OfflineCommit` 是 commit SHA，不能用 tree SHA 代替。離線模式也只寫指定測試資料夾的 `maintenance\reports`。
