﻿[CmdletBinding()]
param(
    [string]$PackRoot,
    [string]$OfflineTreeFile,
    [string]$OfflineCommit
)

# Compatible with Windows PowerShell 5.1. This script never runs upstream code.
$ErrorActionPreference = 'Stop'
$apiRoot = 'https://api.github.com/repos/mathruffian-dot/opencode-lazy-packs'

function Assert-RelativePath([string]$PathValue) {
    if ([string]::IsNullOrWhiteSpace($PathValue) -or
        [IO.Path]::IsPathRooted($PathValue) -or
        $PathValue -match '(^|[/\\])\.\.([/\\]|$)' -or
        $PathValue -match '[:\r\n]') {
        throw "Invalid relative path in manifest or upstream tree: $PathValue"
    }
}

function Get-Category([string]$PathValue) {
    if ($PathValue -match '^(skills|extras)/') { return 'materials' }
    return 'supporting'
}

function Get-UpstreamJson([string]$Url) {
    $headers = @{ 'User-Agent' = 'Calumai-Lazy-Pack-Maintenance'; 'Accept' = 'application/vnd.github+json' }
    # GitHub requires TLS 1.2; preserve any protocols already enabled by the host.
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    return Invoke-RestMethod -Uri $Url -Headers $headers -TimeoutSec 30 -Method Get -ErrorAction Stop
}

function Add-MarkdownSection($Lines, [string]$Title, $Items) {
    $Lines.Add('')
    $Lines.Add("## $Title")
    $Lines.Add('')
    if (@($Items).Count -eq 0) {
        $Lines.Add('- 無。')
        return
    }
    foreach ($item in $Items) {
        $Lines.Add(('- `{0}`（{1}）' -f $item.path, $item.status))
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($PackRoot)) { $PackRoot = Split-Path -Parent $PSScriptRoot }
    $resolvedRoot = (Resolve-Path -LiteralPath $PackRoot -ErrorAction Stop).ProviderPath
    $rootPrefix = $resolvedRoot.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    $manifestPath = Join-Path $resolvedRoot 'maintenance/upstream.json'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw "Manifest not found: $manifestPath"
    }
    $manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.imported_commit -notmatch '^[a-fA-F0-9]{40}$' -or
        $null -eq $manifest.upstream_files -or $null -eq $manifest.local_files) {
        throw 'Manifest requires imported_commit (40 hex characters), upstream_files, and local_files.'
    }
    $beforeFiles = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([StringComparer]::Ordinal)
    foreach ($entry in $manifest.upstream_files) {
        Assert-RelativePath $entry.path
        if ($entry.git_blob_sha -notmatch '^[a-fA-F0-9]{40}$' -or $entry.sha256 -notmatch '^[a-fA-F0-9]{64}$') {
            throw "Invalid upstream hash in manifest: $($entry.path)"
        }
        if ($beforeFiles.ContainsKey($entry.path)) { throw "Duplicate upstream path: $($entry.path)" }
        $beforeFiles.Add($entry.path, $entry)
    }
    if ($OfflineTreeFile) {
        if ($OfflineCommit -notmatch '^[a-fA-F0-9]{40}$') {
            throw 'Offline mode requires -OfflineCommit with the commit SHA (not the tree SHA).'
        }
        $tree = Get-Content -LiteralPath $OfflineTreeFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $currentCommit = $OfflineCommit.ToLowerInvariant()
        $mode = 'offline'
    }
    else {
        if ($OfflineCommit) { throw '-OfflineCommit requires -OfflineTreeFile.' }
        $head = Get-UpstreamJson "$apiRoot/commits/main"
        if ($head.sha -notmatch '^[a-fA-F0-9]{40}$') { throw 'GitHub returned an invalid commit SHA.' }
        $currentCommit = $head.sha.ToLowerInvariant()
        $tree = Get-UpstreamJson "$apiRoot/git/trees/$($currentCommit)?recursive=1"
        $mode = 'live'
    }
    if ($null -eq $tree.tree -or $tree.truncated -eq $true) {
        throw 'Upstream tree is missing or truncated; no report was replaced.'
    }
    $currentFiles = New-Object 'System.Collections.Generic.Dictionary[string,object]' ([StringComparer]::Ordinal)
    foreach ($entry in $tree.tree) {
        if ($entry.type -eq 'tree') { continue }
        if ($entry.type -ne 'blob' -or $entry.mode -notin @('100644', '100755')) {
            throw "Unsupported upstream entry (requires manual review): $($entry.path)"
        }
        Assert-RelativePath $entry.path
        if ($entry.sha -notmatch '^[a-fA-F0-9]{40}$') { throw "Invalid upstream blob SHA: $($entry.path)" }
        if ($currentFiles.ContainsKey($entry.path)) { throw "Duplicate upstream tree path: $($entry.path)" }
        $currentFiles.Add($entry.path, $entry)
    }
    if ($currentFiles.Count -eq 0) { throw 'Upstream tree contains no files; refusing an empty-tree report.' }

    $changes = New-Object 'System.Collections.Generic.List[object]'
    foreach ($path in ($currentFiles.Keys | Sort-Object)) {
        $entry = $currentFiles[$path]
        if (-not $beforeFiles.ContainsKey($path)) {
            $changes.Add([pscustomobject]@{path=$path;status='added';category=(Get-Category $path);previous_git_blob_sha=$null;current_git_blob_sha=$entry.sha})
        }
        elseif ($beforeFiles[$path].git_blob_sha -ne $entry.sha) {
            $changes.Add([pscustomobject]@{path=$path;status='modified';category=(Get-Category $path);previous_git_blob_sha=$beforeFiles[$path].git_blob_sha;current_git_blob_sha=$entry.sha})
        }
    }
    foreach ($path in ($beforeFiles.Keys | Sort-Object)) {
        if (-not $currentFiles.ContainsKey($path)) {
            $changes.Add([pscustomobject]@{path=$path;status='deleted';category=(Get-Category $path);previous_git_blob_sha=$beforeFiles[$path].git_blob_sha;current_git_blob_sha=$null})
        }
    }

    # Always inspect local files, even when the upstream commit has not changed.
    $localChanges = New-Object 'System.Collections.Generic.List[object]'
    $localPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($entry in $manifest.local_files) {
        Assert-RelativePath $entry.path
        if ($entry.sha256 -notmatch '^[a-fA-F0-9]{64}$') { throw "Invalid local SHA256: $($entry.path)" }
        if (-not $localPaths.Add($entry.path)) { throw "Duplicate local path: $($entry.path)" }
        $fullPath = [IO.Path]::GetFullPath((Join-Path $resolvedRoot $entry.path))
        if (-not $fullPath.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Local path escapes pack root: $($entry.path)"
        }
        if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
            $localChanges.Add([pscustomobject]@{path=$entry.path;status='missing';expected_sha256=$entry.sha256;actual_sha256=$null})
            continue
        }
        $hash = (Get-FileHash -LiteralPath $fullPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $entry.sha256.ToLowerInvariant()) {
            $localChanges.Add([pscustomobject]@{path=$entry.path;status='modified';expected_sha256=$entry.sha256;actual_sha256=$hash})
        }
    }

    $added = @($changes | Where-Object { $_.status -eq 'added' })
    $modified = @($changes | Where-Object { $_.status -eq 'modified' })
    $deleted = @($changes | Where-Object { $_.status -eq 'deleted' })
    $materialChanges = @($changes | Where-Object { $_.category -eq 'materials' })
    $supportingChanges = @($changes | Where-Object { $_.category -eq 'supporting' })
    $checkedAt = [DateTimeOffset]::UtcNow.ToOffset([TimeSpan]::FromHours(8)).ToString('yyyy-MM-ddTHH:mm:sszzz')
    $report = [ordered]@{
        checked_at=$checkedAt;mode=$mode;source='https://github.com/mathruffian-dot/opencode-lazy-packs'
        imported_commit=$manifest.imported_commit;current_commit=$currentCommit
        upstream_commit_changed=($manifest.imported_commit -ne $currentCommit)
        summary=[ordered]@{added=$added.Count;modified=$modified.Count;deleted=$deleted.Count;materials=$materialChanges.Count;supporting=$supportingChanges.Count;local_changes=$localChanges.Count}
        added=$added;modified=$modified;deleted=$deleted
        materials=$materialChanges;supporting=$supportingChanges
        local_changes=@($localChanges.ToArray())
    }
    $lines = New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('# Calumai AI agent 懶人包：上游檢查')
    $lines.Add('')
    $lines.Add("檢查時間：$checkedAt（台灣時間）；模式：$mode。")
    $lines.Add(('本地來源版本：`{0}`；上游版本：`{1}`。' -f $manifest.imported_commit, $currentCommit))
    $lines.Add(('上游新增 {0}、修改 {1}、刪除 {2}；本地編修或缺檔 {3}。' -f $added.Count, $modified.Count, $deleted.Count, $localChanges.Count))
    Add-MarkdownSection $lines '教材（skills / extras）' $materialChanges
    Add-MarkdownSection $lines '其他上游檔案' $supportingChanges
    Add-MarkdownSection $lines '本地編修／缺檔（資訊紀錄，不視為檢查失敗）' @($localChanges.ToArray())
    $lines.Add('')
    $lines.Add('這份報告只比較檔名與雜湊，尚未下載新版本全文或驗證教材指令。請人工審查差異、授權與工具現況，再合併；不要直接覆蓋 Calumai 編修。')

    # Reports are the only writable outputs. All network/schema/hash checks finish first.
    $reportsDir = Join-Path $resolvedRoot 'maintenance/reports'
    [void][IO.Directory]::CreateDirectory($reportsDir)
    $encoding = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllText((Join-Path $reportsDir 'latest.json'), ($report | ConvertTo-Json -Depth 12), $encoding)
    [IO.File]::WriteAllText((Join-Path $reportsDir 'latest.md'), ($lines -join "`r`n") + "`r`n", $encoding)
    Write-Output ('Upstream check OK: added={0}, modified={1}, deleted={2}, local_changes={3}' -f $added.Count, $modified.Count, $deleted.Count, $localChanges.Count)
    Write-Output (Join-Path $reportsDir 'latest.md')
    exit 0
}
catch {
    [Console]::Error.WriteLine(('Upstream check failed: {0}' -f $_.Exception.Message))
    exit 1
}
