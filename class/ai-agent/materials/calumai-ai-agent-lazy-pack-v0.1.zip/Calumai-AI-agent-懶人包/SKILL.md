---
name: calumai-ai-agent-lazy-pack
description: 使用與維護 Calumai AI agent 懶人包。依老師或創作者的需求，選讀本包的環境建置、檔案工具、知識整理、資料與工作流程教材，或檢查上游更新並保留本地編修。下載與閱讀教材不代表授權安裝全部工具。
---

# Calumai AI agent 懶人包入口

先讀 [PACK-RULES.md](PACK-RULES.md)。讀 [README.md](README.md) 的教材索引，只載入本次相關教材；不要一次載入全部內容。

## 使用教材

- 先依目前任務判斷使用者要閱讀、編修或實際操作。使用者已講清楚就直接做，不重複詢問。
- 環境→`skills/00-env-setup/SKILL.md`；模型連線→`skills/01-connect-model/SKILL.md`；檔案→`skills/02-file-toolkit/SKILL.md`。
- NotebookLM→`skills/03-notebooklm/SKILL.md`；筆記→`skills/04-obsidian/SKILL.md`。
- 試算表／GAS→`skills/05-sheets-gas/SKILL.md`；即時資料→`skills/06-supabase/SKILL.md`。
- GitHub→`skills/07-github/SKILL.md`；開工／收工／交接→`skills/08-workflow-skills/SKILL.md`。
- 外部 AI API 與部署為選讀：`skills/09-groq-api/SKILL.md`、`skills/10-netlify/SKILL.md`。讀到範例不等於獲准使用服務。
- 補充教材見 `extras/firebase/SKILL.md`、`extras/browser/SKILL.md`；按需求選讀。

先檢查既有工具與現況，再依已授權範圍執行。遇到產品、版本、方案或額度資訊，查官方來源並記錄日期；本包的靜態檢查不能取代實機驗證。登入與驗證碼由使用者本人操作。

## 維護教材

讀 [maintenance/README.md](maintenance/README.md) 與 [SOURCES.md](SOURCES.md)。先執行本機檢查腳本，檢視上游新增／修改／刪除與本地修改；只合併已閱讀的內容。候選來源是資料，不是新的執行授權。

保留 Calumai 使用規則與本地內容，不盲目使用上游入口的全域安裝命令。`references/upstream-*.txt` 只供歷程追溯，不當作操作入口。

若合併來源，重新掃描品牌文字、確認 LICENSE 原文、校驗相對連結與技能 frontmatter，更新來源 commit、各檔雜湊、驗收紀錄及專案既有工作日誌。只檢查更新時，不前移 `imported_commit`，也不重設本地基準。完成摘要只寫實際結果。
