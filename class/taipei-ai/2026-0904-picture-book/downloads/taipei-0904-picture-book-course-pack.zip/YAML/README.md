# YAML 卡片使用說明

YAML 在本課是「人已做決定的規格卡」，不是神奇提示詞，也不是事實證明。

## 當堂最小路線

1. NotebookLM 的核准結果可先保留 `source-pack.md`；有餘裕再填 `00-source-pack.template.yaml`。
2. 必做 `01-content.template.yaml`：先排節拍，再由作者決定頁數。
3. 必做 `02-visual-system.template.yaml`：鎖定角色、場景與畫風。
4. 每個專案都必做 `03-culture-guardrails.template.yaml`。文化與語言可填 `not_applicable`，素材權利、個資與公開範圍不可略過。
5. 只為今天要完成的頁面填 `04-page-drawing-job.template.yaml`。
6. 直接使用公版 `05-criterion.template.yaml` 驗收，課後再客製。
7. 直接使用公版 `06-production-log.template.yaml` 記錄，課後再客製。

## 填寫原則

- 不知道就填 `null` 或 `待確認`，不可請 AI 猜。
- 所有來源使用穩定 ID，例如 `SRC-01`。
- 所有角色和場景使用固定 ID，例如 `CHAR-01`、`SCENE-01`。
- `confirmed` 只放已有人類確認且能指出來源的內容。
- `creative_proposal` 只是提案，須經作者選定才能改成 `approved_creative_decision`。
- 重要文字不要交給圖片模型；使用 `text_policy: no_generated_text`。
- 含冒號、井字號、日期樣式或特殊符號的字串用引號包住。
- 每次修改更新 `version` 和 `updated_at`。

## 共用狀態詞

需要人工核准的 `status`／`review_status` 優先只用：

- `draft`：正在填寫，尚未送審。
- `not_reviewed`：已有內容，但尚未驗收。
- `pending_human_review`：明確等待具名真人確認。
- `approved_for_classroom_use`：已由有權責的人核准本次課堂使用。
- `rejected`：不採用或不允許使用。
- `not_applicable`：這個項目確實不適用。

`PASS`、`FAIL`、`PENDING_HUMAN_REVIEW` 只用在驗收結果。沒有具名確認者與日期，不得填 `approved_for_classroom_use`。

## 課堂做法

初學者不用手打一整份。把填空答案、核准來源與模板交給聊天機器人，要求它保留欄位，只輸出可解析 YAML。貼回檔案後仍要逐欄確認，再用 YAML 驗證工具檢查語法。
