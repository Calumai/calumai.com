# 9/4 AI 繪本課教材包

這是北市府四堂課中的第 1 堂獨立教材，與 CALUMAI 12 堂課分開管理。

## 課程主軸

**來源核對 → 故事節拍 → 分類 YAML → 視覺定錨 → 無字生圖 → 文字後製 → 獨立驗收 → 人工定案**

課堂分工口訣：

> NotebookLM「查、拆、對」；聊天機器人「想、寫、規劃」；人「審、改、定」。

## 三小時的合理完成線

- 經來源核對的故事事實包。
- 6–8 頁完整分鏡與文字計畫。
- 最小 YAML：內容、視覺、權利紅線與至少一頁繪圖工單；驗收與紀錄可沿用公版。
- 至少 1 張完成無字生圖、排版與驗收的頁面。
- PDF 預覽、來源、提示詞與驗收紀錄。

目標完成線是封面＋2 張關鍵內頁；只有已登入工具、使用公版故事和預填模板者才合理期待當堂完成三張。六至八頁全部生圖與精修只列為進階或課後延伸。

## 教材索引

- `講師教案.md`：180 分鐘逐段流程、講法、活動、備援與驗收。
- `學員操作講義.md`：學員從準備素材到交件的操作步驟。
- `工具分工與素材分類.md`：NotebookLM、聊天機器人、生圖、排版與人工審訂的責任邊界。
- `提示詞庫-NotebookLM與聊天機器人.md`：兩類工具可直接改填使用的提示詞。
- `課堂範例-紅雨傘回家了.md`：沒有素材時可用的低文化風險虛構故事與六頁節拍。
- `YAML/README.md`：YAML 卡片順序與使用方法。
- `YAML/00-source-pack.template.yaml`：來源事實包。
- `YAML/01-content.template.yaml`：故事內容與節拍。
- `YAML/02-visual-system.template.yaml`：角色、場景、畫風與輸出規格。
- `YAML/03-culture-guardrails.template.yaml`：文化、語言與授權界線。
- `YAML/04-page-drawing-job.template.yaml`：單頁繪圖工單。
- `YAML/05-criterion.template.yaml`：獨立驗收規格。
- `YAML/06-production-log.template.yaml`：生成、失敗、修正與人工確認紀錄。
- `YAML/範例-紅雨傘回家了/`：逐一對齊模板的完整填寫範例。
- `備援素材/`：兩名跨頁角色三視圖、3 張無字圖、來源事實包、AI 初審、真人放行單與離線排版起始檔。

## YAML 來源透明說明

`captain-comic` 資料庫中實際存在的 YAML 檔是：

- `schemas/drawing_job.template.yaml`
- `schemas/criterion.template.yaml`

另有一段版型選擇 YAML 範例。Captain 方法庫也提出內容、視覺、文化三種責任層；本資料夾因此把方法整理成 7 份適合初學者填寫的**課程衍生模板**。這些模板不是宣稱從原資料庫原封不動複製而來。

## 不可越過的紅線

- 參考圖描述的是該張圖，不得擴大宣稱代表整個族群、所有性別、年代或場合。
- 來源看不到的服飾背面、紋樣意義、器物用途與語言內容不得由 AI 補完。
- 真人、兒童、訪談、地方知識與未公開文件必須先確認上傳、公開與再利用權限。
- 圖片模型不負責正式文字；書名、姓名、族語、標誌及關鍵句一律後製。
- AI 驗收不能取代作者、語言老師、文化知識持有人或權利人的最後決定。

## 方法參考

- Captain Balung：[AI 繪本四階工作流](https://captain-balung-blog.ghost.io/ai-picture-book-workflow/)
- Captain Balung：[固定角色、場景與逐頁設定](https://captain-balung-blog.ghost.io/zuyu-ai-1-3-picturebook-styles/)
- Captain Balung：[內容 YAML 與視覺 YAML 分開](https://captain-balung-blog.ghost.io/zuyu-ai-1-4-yaml-teaching-slides/)
- Captain Balung：[服飾參考轉 YAML 的適用範圍](https://captain-balung-blog.ghost.io/zuyu-ai-2-2-ethnic-poster/)
- Captain Balung：[NotebookLM 製作教材](https://captain-balung-blog.ghost.io/zuyu-ai-2-3-notebooklm/)
- Captain Balung：[NotebookLM 故事簡報](https://captain-balung-blog.ghost.io/zuyu-ai-3-4-notebooklm-story/)
- Google：[NotebookLM 新增與管理來源](https://support.google.com/notebooklm/answer/16215270?co=GENIE.Platform%3DDesktop&hl=en-GB)
- Google：[NotebookLM 概覽與資料政策](https://support.google.com/notebooklm/answer/16164461?hl=en)

課程實際上課前應再確認工具介面、帳號功能與校園政策；方法不綁定單一模型。

## 上課前最後一步

AI 初審不能替素材放行。請由主辦單位或課程權責人填完 `備援素材/上課前放行單.md`；沒有具名確認者與日期時，備援故事與圖片只維持 `pending_human_review`，不可宣稱正式核准或對外公開。
